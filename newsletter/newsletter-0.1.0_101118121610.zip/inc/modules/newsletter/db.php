<?php

$db[ 'newsletter' ] = array(
    'rsn'    => array('int', null, DB_PRIMARY, true),
    'title'  => array('varchar', 255),
);

$db[ 'newsletter_participant' ] = array(
    'rsn'    => array('int', null, DB_PRIMARY, true),
    'newsletter_rsn'  => array('int', null, DB_INDEX),
    'status'  => array('int', null, DB_INDEX), //0: nicht bestaetigt, 1: bestaetigt
    'email'  => array('varchar', '255', DB_INDEX),
    'name'  => array('varchar', '255'),
    'activationKey'  => array('varchar', '32', DB_INDEX),
    'ip'  => array('varchar', '16'),
    'created'  => array('int'),
);


?>
